from pathlib import Path
import ast,json,re
ROOT=Path('/workspace/scratch/226d1e4428b0/pgm-layout-migration')
m=json.loads(Path('/workspace/scratch/226d1e4428b0/layout_migration_evidence/research_moves.json').read_text()); canonical=m['canonical_imports']; cmap=m['campaign_imports']
# Paths encoded in current campaign launchers become repository-relative new paths.
paths={r['old']:r['new'] for r in m['records'] if r.get('new')}
for old,new in list(paths.items()):
 if old.startswith('code/'): paths[old[5:]]=new
for d in ('hp','blockres','structural'):
 for p in (ROOT/'research/campaigns'/d).rglob('*.py'):
  s=p.read_text();tree=ast.parse(s);lines=s.splitlines(keepends=True);offs=[];a=0
  for ln in lines:offs.append(a);a+=len(ln)
  loc=lambda n:(offs[n.lineno-1]+n.col_offset,offs[n.end_lineno-1]+n.end_col_offset)
  edits=[]
  for n in ast.walk(tree):
   if isinstance(n,ast.Constant) and isinstance(n.value,str):
    v=n.value; repl=None
    pre='/Users/adis/Workspace/pgm-records/code/runs/'
    if v.startswith(pre):repl='str(_runs_root() / '+repr(v[len(pre):])+')'
    elif v=='/Users/adis/Workspace/pgm-records':repl='str(_records_root() or (_repo_root() / "research" / "records"))'
    elif v.startswith('/Users/adis/Workspace/pgm-records/'):
     repl='str((_records_root() or (_repo_root() / "research" / "records")) / '+repr(v[len('/Users/adis/Workspace/pgm-records/'):])+')'
    elif v in ('/Users/adis/Workspace/pgm','/Users/adis/Workspace/pgm/code') or re.fullmatch(r'/Users/adis/Workspace/pgm-dgp\d+',v): repl='str(_repo_root())'
    elif v=='/Users/adis/Workspace': repl='str(_repo_root().parent)'
    elif v in paths: repl=repr(paths[v])
    elif v=='gbidi.supervise':repl=repr('pgm.runtime.supervise')
    elif v=='code/cex':repl=repr('src/pgm/algorithms')
    elif v=='code/gbidi':repl=repr('src/pgm/runtime')
    if repl:edits.append((*loc(n),repl))
   elif isinstance(n,ast.Import):
    amap={'oracle':'pgm.algorithms.cqr.oracle','task':'pgm.algorithms.cqr.task','compiler':'pgm.algorithms.cqr.compiler','frontier':'pgm.algorithms.cqr.frontier'}
    if any(x.name in amap for x in n.names):
     parts=[amap.get(x.name,x.name)+(' as '+(x.asname or x.name) if x.name in amap else (' as '+x.asname if x.asname else '')) for x in n.names];edits.append((*loc(n),'import '+', '.join(parts)))
   elif isinstance(n,ast.ImportFrom) and n.module in ('oracle','task','compiler','frontier') and n.level==0:
    edits.append((*loc(n),'from pgm.algorithms.cqr.'+n.module+' import '+', '.join(x.name+(' as '+x.asname if x.asname else '') for x in n.names)))
  for a,b,v in sorted(edits,reverse=True):s=s[:a]+v+s[b:]
  # Source path identity lists are now repository-relative, not relative to an obsolete code root.
  s=re.sub(r"os\.path\.join\((root|code_root|CODE|SUP_CODE), ['\"]code['\"], ",r'os.path.join(\1, ',s)
  s=re.sub(r"os\.path\.join\((root|code_root), ['\"]code['\"]\)",r'str(\1)',s)
  s=re.sub(r"os\.path\.join\((CODE|SUP_CODE), ['\"]\.venv/bin/python['\"]\)","sys.executable",s)
  # Dead pre-migration search-path loops have no semantic purpose after imports were qualified.
  s=re.sub(r"(?m)^for p in \(HERE,.*\):\n    if p not in sys\.path: None\n",'',s)
  s=re.sub(r"; None(?=;|\n)",'',s)
  s=re.sub(r'(?m)^None\n','',s)
  # Canonical source files are used by validation hashes and native test-driver compilation.
  for name,module in canonical.items():
   s=s.replace("HERE / '"+name+".py'", "Path(_source_path("+repr(module)+"))")
   s=s.replace("base / '"+name+".py'", "Path(_source_path("+repr(module)+"))")
  p.write_text(s);ast.parse(s)
print('operational paths and CQR imports rewritten')
