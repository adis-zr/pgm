from pathlib import Path
import hashlib,json
r=Path('/workspace/scratch/226d1e4428b0/pgm-layout-migration')
moves={
'code/bench/cbi_adapter.py':'benchmarks/external/tools/cbi_adapter.py',
'code/bench/cells.py':'research/comparators/legacy_cells.py',
'code/bench/pgmax_mar.py':'benchmarks/external/comparators/pgmax_mar.py',
'code/bench/libdai/libdai_mar.cpp':'benchmarks/external/comparators/libdai/libdai_mar.cpp',
'code/ext/uai.py':'benchmarks/external/tools/uai.py',
'code/ext/supervise.py':'research/comparators/legacy_ext/supervise.py',
'code/ext/comparator/merlin_adapter.py':'research/comparators/legacy_ext/merlin_adapter.py',
'code/ext/comparator/MERLIN_PIN.json':'research/comparators/legacy_ext/MERLIN_PIN.json',
'code/ext/comparator/__init__.py':'research/comparators/legacy_ext/__init__.py',
'documentation/consolidation/step1/tools/clean_wheel_relocation_test.py':'tests/qualification/clean_wheel_relocation_test.py',
'documentation/consolidation/step1/tools/run_inherited_controls.py':'tests/qualification/run_inherited_controls.py',
'documentation/consolidation/step1/tools/qualify_step1.sh':'tests/qualification/qualify.sh',
}
for p in (r/'code/bench/controls').iterdir():
 if p.is_file(): moves[str(p.relative_to(r))]='benchmarks/external/fixtures/legacy/'+p.name
for name in ('test_cbi_conformance.py','test_sf_conformance.py','test_h4a_review2.py'): moves['code/tests/'+name]='tests/specialists/'+name
for name in ('test_bench_adapters.py','test_ext_adapter.py'): moves['code/tests/'+name]='tests/benchmark_legacy/'+name
for name in ('relocate_closures.py','classify_tree.py','closure_inventory.py','manifest.py'): moves['documentation/consolidation/step1/tools/'+name]='research/archive/layout_tools/'+name
ledger=[]
for old,new in moves.items():
 src,dst=r/old,r/new; dst.parent.mkdir(parents=True,exist_ok=True)
 digest=hashlib.sha256(src.read_bytes()).hexdigest(); src.rename(dst)
 ledger.append(dict(old=old,new=new,old_sha256=digest))
for directory in ('benchmarks','benchmarks/external','benchmarks/external/tools','benchmarks/external/comparators','research/comparators','tests/specialists','tests/benchmark_legacy','tests/qualification'):
 p=r/directory/'__init__.py'
 if not p.exists(): p.write_text('"""Repository tooling; not part of the installed inference package."""\n')
(r/'research/archive/layout_tools/README.md').write_text('# Historical layout tooling\n\nThese scripts are retained byte for byte from consolidation step 1. They describe that historical layout and its file counts, not the current tree, and must not be run to overwrite archived qualification records. Current qualification is `tests/qualification/qualify.sh`.\n')
Path('/workspace/scratch/226d1e4428b0/layout_migration_evidence/benchmark_moves.json').write_text(json.dumps(ledger,indent=2)+'\n')

def edit(rel, changes):
 p=r/rel;s=p.read_text()
 for old,new in changes:
  if old not in s: print('UNMATCHED',rel,repr(old))
  s=s.replace(old,new)
 p.write_text(s)
for rel in ('benchmarks/external/tools/cbi_adapter.py','benchmarks/external/comparators/pgmax_mar.py'):
 edit(rel,[('sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))\n',''),('from ext import uai as U','from benchmarks.external.tools import uai as U')])
edit('research/comparators/legacy_ext/merlin_adapter.py', [('HERE = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))\nsys.path.insert(0, HERE)\n',''),('from ext import supervise as SV','from research.comparators.legacy_ext import supervise as SV'),('ext.supervise.run','research.comparators.legacy_ext.supervise.run'),('ext.comparator.merlin_adapter','research.comparators.legacy_ext.merlin_adapter')])
edit('research/comparators/legacy_cells.py', [('HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__))); sys.path.insert(0, HERE)','from pathlib import Path\nHERE = str(Path(__file__).resolve().parents[2])'),('os.path.join(HERE, "bench", "libdai", "libdai_mar")','os.environ.get("PGM_LIBDAI", os.path.join(HERE, "benchmarks", "external", "comparators", "libdai", "libdai_mar"))'),('from ext import uai','from benchmarks.external.tools import uai'),('from bench import cbi_adapter','from benchmarks.external.tools import cbi_adapter'),('from cbi import','from pgm.algorithms.cbi import'),('os.path.join(HERE, "bench", "pgmax_mar.py")','"-m", "benchmarks.external.comparators.pgmax_mar"')])
for rel in ('tests/benchmark_legacy/test_bench_adapters.py','tests/benchmark_legacy/test_ext_adapter.py','tests/specialists/test_cbi_conformance.py','tests/specialists/test_sf_conformance.py'):
 p=r/rel;s=p.read_text();s=s.replace('HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__))); sys.path.insert(0, HERE)','from pathlib import Path\nHERE = str(Path(__file__).resolve().parents[2])').replace('HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))\nsys.path.insert(0, HERE)','from pathlib import Path\nHERE = str(Path(__file__).resolve().parents[2])')
 s=s.replace('from ext import uai','from benchmarks.external.tools import uai').replace('from bench import cbi_adapter','from benchmarks.external.tools import cbi_adapter').replace('from bench import cells as CE','from research.comparators import legacy_cells as CE').replace('from cbi import','from pgm.algorithms.cbi import').replace('from sf import','from pgm.algorithms.sf import')
 s=s.replace(', generators as G','').replace(', generate as GEN','')
 if rel.endswith('test_cbi_conformance.py'): s=s.replace('Q = 1 << A.GRID_BITS','from research.campaigns.cbi import generators as G\n\nQ = 1 << A.GRID_BITS')
 if rel.endswith('test_sf_conformance.py'): s=s.replace('\n\ndef brute', '\nfrom research.campaigns.sf import generate as GEN\n\ndef brute')
 if rel.endswith('test_bench_adapters.py'):
  s=s.replace('    from pgm.algorithms.cbi import plan as PL','    from pgm.algorithms.cbi import plan as PL\n    from research.campaigns.cbi import generators as G')
  s=s.replace('drv = os.path.join(HERE, "bench", "libdai", "libdai_mar"); C = os.path.join(HERE, "bench", "controls")','drv = os.environ.get("PGM_LIBDAI", os.path.join(HERE, "benchmarks", "external", "comparators", "libdai", "libdai_mar")); C = os.path.join(HERE, "benchmarks", "external", "fixtures", "legacy")')
 p.write_text(s)
edit('tests/specialists/test_h4a_review2.py', [('HERE = pathlib.Path(__file__).resolve().parent.parent; sys.path.insert(0, str(HERE))','HERE = pathlib.Path(__file__).resolve().parents[2]'),('from h4a','from pgm.algorithms.h4'),('str(HERE.parent / "docs" / "h4-arithmetic-contract-2026-10-27")','str(pathlib.Path(os.environ.get("PGM_RECORDS_ROOT", str(HERE))) / "docs" / "h4-arithmetic-contract-2026-10-27")'),('BUILD = HERE / "build"','from pgm.algorithms.h4.kernels import build_dir\nBUILD = build_dir()')])
edit('tests/test_qualification_tools.py',[('documentation/consolidation/step1/tools','tests/qualification'),('cqr=dict(kind="UNAVAILABLE")','cqr=dict(kind="LOADED", origin="/x/site-packages/pgm/algorithms/cqr/task.py")'),('"cqr silently available": lambda r: r["steps"]["specialists"]["result"]["cqr"].update(kind="LOADED")','"cqr missing from wheel": lambda r: r["steps"]["specialists"]["result"]["cqr"].update(kind="UNAVAILABLE")')])
for rel in ('tests/qualification/clean_wheel_relocation_test.py','tests/qualification/run_inherited_controls.py'): edit(rel,[('parents[4]','parents[2]')])
edit('tests/qualification/run_inherited_controls.py',[('code/cex/hp/check_dgp.py','research/campaigns/hp/check_dgp.py'),('str(REPO / "code")','str(REPO)')])
edit('tests/qualification/clean_wheel_relocation_test.py', [('cqr typed UNAVAILABLE','installed cqr load'),('if (sp.get("cqr") or {}).get("kind") != "UNAVAILABLE": failures.append("specialists: cqr must be typed UNAVAILABLE from the wheel")','if (sp.get("cqr") or {}).get("kind") != "LOADED" or "site-packages" not in str((sp.get("cqr") or {}).get("origin", "")): failures.append("specialists: cqr must load from the installed wheel")'),('from pgm.specialists import cbi, sf, h4a, cqr, _bridge','from pgm.specialists import cbi, sf, h4a, cqr'),('api, model = cbi.modules(); from cbi import generators as G\nobj = G.mesh(2, 2, 4, 6, Fr(1, 64), 3); res = api.solve(obj, "all", "1/100"); ver = api.verify(obj, res)','api, model = cbi.modules()\nobj = {"d": 1, "blocks": [{"id": 0, "rows": [0, 1], "weights": [1, 2]}, {"id": 1, "rows": [0, 1], "weights": [3, 1]}], "edges": [{"u": 0, "v": 1, "r": "1/2"}]}\nres = api.solve(obj, "all", "1/100"); ver = api.verify(obj, res)'),('try:\n    cqr.load_task("fixtures/asym2.uai"); out["cqr"] = dict(kind="LOADED")\nexcept _bridge.SpecialistUnavailable as e:\n    out["cqr"] = dict(kind=e.kind, reason=str(e))\nout["bridge_code_root"] = str(_bridge.code_root()); print(json.dumps(out))','cqr.load_task("fixtures/asym2.uai"); out["cqr"] = dict(kind="LOADED", origin=cqr.modules()[0].__file__)\nprint(json.dumps(out))')])
edit('benchmarks/external/strict_supervisor.py',[('from gbidi import supervise','from pgm.runtime import supervise')])
edit('benchmarks/external/run_suite.py',[('REPO / "code/bench/libdai/libdai_mar"','REPO / "benchmarks/external/comparators/libdai/libdai_mar"'),('str(REPO / "src") + os.pathsep + str(REPO / "code")','str(REPO / "src")')])
edit('benchmarks/external/run_performance.py',[('REPO / "code/bench/libdai/libdai_mar"','REPO / "benchmarks/external/comparators/libdai/libdai_mar"'),('env.update(PYTHONPATH=os.pathsep.join((str(root / "src"), str(root / "code"))),','paths = (root / "src", root / "code") if key == "baseline" else (root / "src",)\n    env.update(PYTHONPATH=os.pathsep.join(map(str, paths)),')])
edit('benchmarks/external/provenance/BUILD_LIBDAI.sh',[('../pgm-external-benchmark/code/bench/libdai/libdai_mar.cpp','"${PGM_ROOT:?Set PGM_ROOT to the library checkout}/benchmarks/external/comparators/libdai/libdai_mar.cpp"')])
