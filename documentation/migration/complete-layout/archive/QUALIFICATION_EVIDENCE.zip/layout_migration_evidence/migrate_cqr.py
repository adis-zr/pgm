from pathlib import Path
import ast,hashlib,json,re,shutil
root=Path('/workspace/scratch/226d1e4428b0/pgm-layout-migration')
old=root/'code/cex/cqr'; runtime=root/'src/pgm/algorithms/cqr'; research=root/'research/campaigns/cqr'
runtime.mkdir(parents=True,exist_ok=True);research.mkdir(parents=True,exist_ok=True)
rt={'task','views','compiler','frontier','reference','numerics','structural','diag','oracle','solve','checker'}
research_names={p.stem for p in old.glob('*.py')}-rt-{'__init__'}
structural={'core','forest','dag','support','stream','stream_float','cex_executor','reduction'}
moves=[]
for source in sorted(old.iterdir()):
 if source.name=='__pycache__': continue
 target=(runtime if source.stem in rt or source.name=='__init__.py' else research)/source.name
 moves.append(dict(old=str(source.relative_to(root)),new=str(target.relative_to(root)),kind='runtime' if target.parent==runtime else 'research',old_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),reason='Single canonical runtime copy; imports namespaced.' if target.parent==runtime else 'Campaign/provenance/analysis tooling outside the installed runtime.'))
 shutil.move(source,target)
# Namespace bare imports while preserving all solver/control logic.
for folder in (runtime,research):
 for p in folder.glob('*.py'):
  text=p.read_text(); tree=ast.parse(text); lines=text.splitlines(keepends=True); offsets=[0]
  for line in lines: offsets.append(offsets[-1]+len(line))
  edits=[]
  for node in ast.walk(tree):
   if isinstance(node,ast.Import):
    pieces=[]; changed=False
    for alias in node.names:
     n=alias.name; suffix=(' as '+alias.asname) if alias.asname else ''
     if n in rt:
      ns='.' if folder==runtime else 'pgm.algorithms.cqr'
     elif n in research_names: ns='research.campaigns.cqr'
     elif n in structural: ns='pgm.algorithms.structural'
     else: ns=None
     pieces.append(('from '+ns+' import '+n+suffix) if ns else 'import '+n+suffix);changed|=ns is not None
    if changed: edits.append((offsets[node.lineno-1]+node.col_offset,offsets[node.end_lineno-1]+node.end_col_offset,'; '.join(pieces)))
   elif isinstance(node,ast.ImportFrom) and node.level==0 and node.module in rt|structural|research_names:
    ns=('.' if folder==runtime else 'pgm.algorithms.cqr.') if node.module in rt else ('pgm.algorithms.structural.' if node.module in structural else 'research.campaigns.cqr.')
    imp='from '+ns+node.module+' import '+', '.join(a.name+(' as '+a.asname if a.asname else '') for a in node.names)
    edits.append((offsets[node.lineno-1]+node.col_offset,offsets[node.end_lineno-1]+node.end_col_offset,imp))
  for start,end,new in sorted(edits,reverse=True): text=text[:start]+new+text[end:]
  # Remove checkout import-path bootstraps, including those inside research test helpers.
  tree=ast.parse(text);lines=text.splitlines(keepends=True);offsets=[0]
  for line in lines:offsets.append(offsets[-1]+len(line))
  edits=[]
  def path_call(n): return isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and isinstance(n.func.value,ast.Attribute) and isinstance(n.func.value.value,ast.Name) and n.func.value.value.id=='sys' and n.func.value.attr=='path'
  for node in ast.walk(tree):
   if isinstance(node,(ast.For,ast.If)) and any(path_call(n) for n in ast.walk(node)):
    # These are only legacy import bootstraps, not inference branches.
    edits.append((offsets[node.lineno-1]+node.col_offset,offsets[node.end_lineno-1]+node.end_col_offset,'pass  # imports are package-qualified'))
   elif isinstance(node,ast.Expr) and path_call(node.value): edits.append((offsets[node.lineno-1]+node.col_offset,offsets[node.end_lineno-1]+node.end_col_offset,'pass  # imports are package-qualified'))
  # Drop edits nested inside an already removed path-bootstrap node.
  outer=[]
  for e in sorted(edits):
   if not outer or e[0]>=outer[-1][1]:outer.append(e)
  for start,end,new in reversed(outer):text=text[:start]+new+text[end:]
  if folder==runtime:
   text=re.sub(r'^HERE = .*NEWARM = .*\n','',text,flags=re.M)
   text=re.sub(r'^pass  # imports are package-qualified\n','',text,flags=re.M)
  p.write_text(text)
(runtime/'__init__.py').write_text('"""Certified finite-query refinement: exact, deterministic, and PAC task semantics."""\n')
(research/'__init__.py').write_text('"""CQR campaign, provenance, qualification and analysis tools; not runtime dependencies."""\n')
for entry in moves:
 target=root/entry['new'];entry['new_sha256']=hashlib.sha256(target.read_bytes()).hexdigest()
Path('/workspace/scratch/226d1e4428b0/layout_migration_evidence/cqr_moves.json').write_text(json.dumps(dict(moves=moves),indent=2)+'\n')
