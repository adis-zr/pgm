from pathlib import Path
r=Path('/workspace/scratch/226d1e4428b0/pgm-layout-migration')
for rel,alias in [('benchmarks/external/run_performance.py','checks'),('benchmarks/external/analyze_performance.py','h')]:
 p=r/rel;s=p.read_text();s=s.replace(f'import run_suite as {alias}\nfrom benchmark_validity import censored_comparator, censored_fields, check_public_output',f'if __package__:\n    from . import run_suite as {alias}\n    from .benchmark_validity import censored_comparator, censored_fields, check_public_output\nelse:\n    import run_suite as {alias}\n    from benchmark_validity import censored_comparator, censored_fields, check_public_output')
 if 'run_performance' in rel:s=s.replace('            from analyze_performance import main as analyze_main','            if __package__:\n                from .analyze_performance import main as analyze_main\n            else:\n                from analyze_performance import main as analyze_main')
 p.write_text(s)
p=r/'benchmarks/external/analyze_suite.py';s=p.read_text().replace('import run_suite as h','if __package__:\n    from . import run_suite as h\nelse:\n    import run_suite as h');p.write_text(s)
p=r/'tests/benchmark_legacy/test_ext_adapter.py';s=p.read_text();s='\n'.join(x for x in s.splitlines() if not x.startswith('sys.path.insert('))+'\n';p.write_text(s)
p=r/'tests/qualification/clean_wheel_relocation_test.py';s=p.read_text();old='''cqr.load_task("fixtures/asym2.uai"); out["cqr"] = dict(kind="LOADED", origin=cqr.modules()[0].__file__)
print(json.dumps(out))''';new='''from pathlib import Path
from pgm.algorithms.cqr import task as task_module, checker
model_path = Path("cqr_exact.uai")
model_path.write_text("MARKOV\\n2\\n2 2\\n1\\n2 0 1\\n4\\n1 2 3 4\\n")
checks = {}
for label, queries, normalizer, expected in (
    ("queries", [dict(kind="joint", assign={"0": 1, "1": 1}), dict(kind="parity", variables=[0, 1], bit=1), dict(kind="conditional", event={"0": 1}, given={"1": 0})], False, [Fr(2, 5), Fr(1, 2), Fr(3, 4)]),
    ("normalizer", [], True, [Fr(10)]),
):
    Path(str(model_path) + ".query.json").write_text(json.dumps(dict(mode="EXACT_RATIONAL", epsilon="1/200", delta="0", queries=queries, normalizer_task=normalizer)))
    task = cqr.load_task(model_path); arm = "N1_NO_STRUCTURAL"
    result = cqr.solve(task, time.monotonic() + 5, arm, "wheel")
    assert result["outcome"] == "PUBLISHED", result
    pub = result["publication"]; names = ["Z"] if normalizer else [q.name for q in task["queries"]]
    worker = dict(result, status="COMPLETED", arm=arm, binding=task["binding"], task_identity=task_module.task_identity(task), mode=task["mode"], epsilon=str(task["epsilon"]), delta=str(task["delta"]), route=pub["route"], exact=bool(pub.get("exact")), answers=[dict(query=name, lo=str(lo), hi=str(hi), point=str(point), status="OK") for name, (lo, hi), point in zip(names, pub["bounds"], pub["point"])])
    failures, _ = checker.check_worker_output(str(model_path), json.loads(json.dumps(worker, default=str)), arm=arm, deadline=time.monotonic() + 5)
    assert failures == [], failures
    assert list(pub["point"]) == expected and list(pub["bounds"]) == [(v, v) for v in expected]
    checks[label] = dict(verified=True, points=[str(v) for v in pub["point"]])
out["cqr"] = dict(kind="VERIFIED", origin=task_module.__file__, cases=checks)
import pgm
out["method_registry"] = {name: dict(module=pgm.method(name).api.__name__, status=pgm.method(name).metadata["status"]) for name in ("cbi", "sf", "cqr", "h4")}
print(json.dumps(out))'''
assert old in s;s=s.replace(old,new)
s=s.replace('if (sp.get("cqr") or {}).get("kind") != "LOADED" or "site-packages" not in str((sp.get("cqr") or {}).get("origin", "")): failures.append("specialists: cqr must load from the installed wheel")','''cqr = sp.get("cqr") or {}
        if cqr.get("kind") != "VERIFIED" or "site-packages" not in str(cqr.get("origin", "")) or cqr.get("cases") != {"queries": {"verified": True, "points": ["2/5", "1/2", "3/4"]}, "normalizer": {"verified": True, "points": ["10"]}}: failures.append("specialists: CQR exact queries and normalizer must solve and independently verify from the wheel")
        registry = sp.get("method_registry") or {}
        if set(registry) != {"cbi", "sf", "cqr", "h4"} or any(not item.get("module", "").startswith("pgm.") or item.get("status") != "specialist" for item in registry.values()): failures.append("specialists: public method registry")''')
p.write_text(s)
p=r/'tests/test_qualification_tools.py';s=p.read_text().replace('cqr=dict(kind="LOADED", origin="/x/site-packages/pgm/algorithms/cqr/task.py")','cqr=dict(kind="VERIFIED", origin="/x/site-packages/pgm/algorithms/cqr/task.py", cases=dict(queries=dict(verified=True, points=["2/5", "1/2", "3/4"]), normalizer=dict(verified=True, points=["10"]))), method_registry={name: dict(module="pgm.specialists." + name, status="specialist") for name in ("cbi", "sf", "cqr", "h4")}')
s=s.replace('        "required step missing":', '        "cqr wrong exact query": lambda r: r["steps"]["specialists"]["result"]["cqr"]["cases"]["queries"].update(points=["1/2", "1/2", "3/4"]),\n        "cqr checker not run": lambda r: r["steps"]["specialists"]["result"]["cqr"]["cases"]["normalizer"].update(verified=False),\n        "method omitted": lambda r: r["steps"]["specialists"]["result"]["method_registry"].pop("cqr"),\n        "required step missing":')
p.write_text(s)
