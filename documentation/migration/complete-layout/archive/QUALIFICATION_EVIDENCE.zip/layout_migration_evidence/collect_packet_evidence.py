#!/usr/bin/env python3
"""Collect compact, byte-preserved layout-migration evidence outside the repository.

Usage: collect_packet_evidence.py NEW_OUTPUT.zip [--workspace DIR]
       collect_packet_evidence.py NEW_OUTPUT_DIRECTORY [--workspace DIR]

By default both completed qualification passes are required. --allow-incomplete
creates a clearly labelled development snapshot and never claims final closure.
No tests run, source trees change, or older evidence files are overwritten.
"""
from __future__ import annotations
import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import tempfile
import zipfile

DEFAULT_WORKSPACE = Path(__file__).resolve().parents[1]
NATIVE_RECORDS = {"cex_build.json", "stream_build.json", "heatbath_build.json", "h4point.json", "h4pcheck.json", "h4rect.json"}
EXCLUDED_DIRECTORIES = {"venv", ".venv", "__pycache__", "source", "wheel_source", "wheel_dev_source", "generated_legacy_tree", ".git", "pip"}


def digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def descendants(root):
    """Do not descend into virtualenvs, restored source, pip caches or symlinks."""
    if not root.is_dir():
        return
    for directory, names, files in os.walk(root, followlinks=False):
        current = Path(directory)
        names[:] = sorted(name for name in names if name not in EXCLUDED_DIRECTORIES and not (current / name).is_symlink())
        for name in sorted(files):
            path = current / name
            if not path.is_symlink() and path.is_file():
                yield path


def select(workspace, allow_incomplete):
    selected = {}
    missing = []
    categories = Counter()

    def add(path, category):
        if path.is_symlink() or not path.is_file():
            return
        relative = path.relative_to(workspace).as_posix()
        selected[relative] = (path, category)

    def needed(path):
        if not path.is_file():
            missing.append(path.relative_to(workspace).as_posix())

    evidence = workspace / "layout_migration_evidence"
    for path in sorted(evidence.iterdir()):
        if path.suffix.lower() in {".json", ".jsonl", ".log", ".txt", ".md", ".py", ".sh"}:
            add(path, "development_and_review")
    for filename in ("independent_review.json", "independent_review.md", "benchmark_moves.json", "research_moves.json"):
        needed(evidence / filename)

    for name in ("layout_migration_qualification", "layout_migration_qualification_retry"):
        run = workspace / name
        needed(run / "qualification/QUALIFICATION.json")
        needed(run / "qualification/COMMANDS.log")
        needed(run / "qualification/SOURCE_COMMIT.txt")
        needed(run / "qualification/clean_wheel_relocation.json")
        wheels = sorted((run / "dist").glob("*.whl"))
        if not wheels:
            missing.append(name + "/dist/*.whl")
        for path in descendants(run / "qualification"):
            add(path, "qualification")
        if (run / "parity_final.json").is_file():
            add(run / "parity_final.json", "qualification")
        for path in wheels:
            add(path, "tested_wheel")
        collect_relocation(run / "relocation", add)

    # Preserve the failed development wheel attempts, not their environments or
    # temporary source copies. Generated native witness inputs are retained only
    # alongside their actual checker outputs.
    for root in sorted(evidence.glob("wheel_dev_relocation*")):
        collect_relocation(root, add)
    for path in (evidence / "wheel_dev_dist").glob("*.whl"):
        add(path, "development_wheel")

    replay = evidence / "frozen_replay"
    for path in descendants(replay):
        if path.suffix.lower() in {".json", ".log", ".csv", ".md"}:
            add(path, "frozen_732_replay")
    needed(replay / "RESTORE_RECEIPT.json")
    needed(replay / "analysis/REPLAY_RECEIPT.json")

    # These tiny generated inputs are the inputs to the retained libDAI oracle
    # checks, rather than a second copy of the external inference benchmark.
    for path in descendants(evidence / "libdai_qualification"):
        if path.suffix.lower() in {".json", ".mar", ".uai", ".evid", ".log"}:
            add(path, "comparator_qualification")

    toolchain = workspace / "layout_migration_toolchain"
    for path in (toolchain / "MPFR_DEV.json", toolchain / "env.sh"):
        add(path, "toolchain_identity")
    for path in descendants(toolchain / "native_cache"):
        if path.name in NATIVE_RECORDS:
            add(path, "native_build_records")
    for relative, (_, category) in selected.items():
        categories[category] += 1
    if missing and not allow_incomplete:
        raise RuntimeError("Qualification is not complete; no final packet created: " + ", ".join(missing))
    return selected, missing, dict(sorted(categories.items()))


def collect_relocation(root, add):
    for path in descendants(root):
        parts = path.relative_to(root).parts
        if path.name in NATIVE_RECORDS:
            add(path, "native_build_records")
        elif path.name == "clean_wheel_relocation.json" or path.name == "installed_snapshot.json":
            add(path, "wheel_execution")
        elif path.name.startswith(("worker_", "out_")) and path.suffix == ".json":
            add(path, "wheel_execution")
        elif "h4_witness" in parts and path.suffix in {".json", ".txt"}:
            add(path, "wheel_native_witness")
        elif path.name in {"cqr_exact.uai", "cqr_exact.uai.query.json"}:
            add(path, "wheel_query_input")


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("output", type=Path)
    parser.add_argument("--workspace", type=Path, default=DEFAULT_WORKSPACE)
    parser.add_argument("--allow-incomplete", action="store_true")
    args = parser.parse_args(argv)
    workspace = args.workspace.expanduser().resolve()
    output = args.output.expanduser().resolve()
    if output.exists():
        parser.error("Output must not exist; evidence is never overwritten")
    if output.is_relative_to(workspace / "pgm-layout-migration") or output.is_relative_to(workspace / "layout_migration_evidence"):
        parser.error("Output must be outside the repository and evidence input directory")
    selected, missing, categories = select(workspace, args.allow_incomplete)
    output.parent.mkdir(parents=True, exist_ok=True)
    as_zip = output.suffix.lower() == ".zip"
    temporary = tempfile.TemporaryDirectory(prefix="pgm-migration-packet-") if as_zip else None
    destination = Path(temporary.name) if temporary else output
    destination.mkdir(parents=True, exist_ok=True)
    copied = []
    try:
        for relative, (source, category) in sorted(selected.items()):
            target = destination / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            before = digest(source)
            shutil.copy2(source, target)
            after = digest(source)
            if before != after or digest(target) != before:
                raise RuntimeError("Evidence changed while collecting: " + relative)
            copied.append(dict(path=relative, sha256=before, bytes=target.stat().st_size, category=category))
        manifest = dict(schema="PGM_LAYOUT_EVIDENCE_PACKET_1", collected_utc=datetime.now(timezone.utc).isoformat(),
                        status="DEVELOPMENT_SNAPSHOT_INCOMPLETE" if missing else "BOTH_QUALIFICATION_RUNS_PRESENT",
                        missing_required=missing, workspace=str(workspace), categories=categories,
                        file_count=len(copied), total_bytes=sum(row["bytes"] for row in copied), files=copied,
                        exclusions=["virtualenvs", "restored source worktrees", "wheel source copies", "pip caches", "bytecode", "large historical benchmark packets", "native binaries (build records retained)", "generated fixtures except inputs accompanying retained comparator/CQR/H4 raw checks"])
        (destination / "MANIFEST.json").write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n")
        (destination / "README.txt").write_text("Compact layout-migration evidence. Files are copied byte for byte; their original paths relative to the workspace are retained. MANIFEST.json binds each file. Both the first qualification attempt and the retry remain visible; their own verdicts are authoritative. This packet adds no inference cells and does not replace the separately archived 732-cell benchmark. Source and Git history are delivered in the accompanying bundle.\n")
        if as_zip:
            with zipfile.ZipFile(output, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
                for path in sorted(destination.rglob("*")):
                    if path.is_file():
                        archive.write(path, path.relative_to(destination).as_posix())
            with zipfile.ZipFile(output) as archive:
                for row in copied:
                    if hashlib.sha256(archive.read(row["path"])).hexdigest() != row["sha256"]:
                        raise RuntimeError("Archive verification failed: " + row["path"])
            size = output.stat().st_size
            receipt = dict(output=str(output), sha256=digest(output), zip_bytes=size, status=manifest["status"], file_count=len(copied), uncompressed_bytes=manifest["total_bytes"], categories=categories)
        else:
            receipt = dict(output=str(output), status=manifest["status"], file_count=len(copied), uncompressed_bytes=manifest["total_bytes"], manifest_sha256=digest(destination / "MANIFEST.json"), categories=categories)
        print(json.dumps(receipt, indent=2, sort_keys=True))
        return 0
    finally:
        if temporary:
            temporary.cleanup()


if __name__ == "__main__":
    raise SystemExit(main())
