from pathlib import Path
r=Path('/workspace/scratch/226d1e4428b0/pgm-layout-migration')
p=r/'benchmarks/external/run_suite.py';s=p.read_text().replace('record=str(SF.BASE / "stream_build.json") if os.access(SF.BASE, os.W_OK) and not os.environ.get("PGM_NATIVE_CACHE") else os.path.join(R.writable_home(SF.BASE), "stream_build.json")','record=os.path.join(R.writable_home(SF.BASE), "stream_build.json")');p.write_text(s)
p=r/'tests/qualification/clean_wheel_relocation_test.py';s=p.read_text();s=s.replace('h4a availability report, installed cqr load','H4 native witnesses, checked CQR queries and normalizer')
s=s.replace('env["PATH"] = str(venv / "bin") + os.pathsep + env.get("PATH", "")', 'env["PATH"] = str(venv / "bin") + os.pathsep + env.get("PATH", ""); env["XDG_CACHE_HOME"] = str(work / "default_cache")')
old='"mods={m: (getattr(sys.modules[m], \'__file__\', None) or \'\') for m in sys.modules if m.startswith(\'pgm\')};"'
new='''"from pathlib import Path; import hashlib; package=Path(pgm.__file__).parent; "
                              "snapshot={str(p.relative_to(package)): hashlib.sha256(p.read_bytes()).hexdigest() for p in package.rglob('*') if p.is_file() and '__pycache__' not in p.parts}; Path('installed_snapshot.json').write_text(json.dumps(snapshot)); "
                              "mods={m: (getattr(sys.modules[m], '__file__', None) or '') for m in sys.modules if m.startswith('pgm')};"'''
assert old in s;s=s.replace(old,new)
old='''r = run([str(py), "-I", "-c", "import pgm.algorithms.structural.cex_executor as CX, pgm.algorithms.structural.stream_float as SF, pgm.algorithms.response.heatbath_native as HN, json, os; print(json.dumps(dict(cex_lib=str(CX.LIB), cex_lib_exists=os.path.exists(CX.LIB), cex_record=str(CX.RECORD), stream_lib=str(SF.LIB), stream_lib_exists=os.path.exists(SF.LIB), heat_record=str(HN.RECORD), heat_record_exists=os.path.exists(HN.RECORD))))"], env, work)'''
new='''locations = r\'\'\'
from pathlib import Path
import hashlib, json, pgm
import pgm.algorithms.structural.cex_executor as CX, pgm.algorithms.structural.stream_float as SF, pgm.algorithms.response.heatbath_native as HN
from pgm.runtime.resources import native_cache_dir
package = Path(pgm.__file__).parent.resolve()
paths = {"cex_lib": Path(CX.LIB), "stream_lib": Path(SF.LIB), "heat_record": Path(HN.RECORD)}
owners = {"cex_lib": CX.BASE, "stream_lib": SF.BASE, "heat_record": HN.HERE}
snapshot = {str(p.relative_to(package)): hashlib.sha256(p.read_bytes()).hexdigest() for p in package.rglob("*") if p.is_file() and "__pycache__" not in p.parts}
print(json.dumps(dict(**{name: str(path) for name, path in paths.items()}, **{name + "_exists": path.is_file() for name, path in paths.items()},
    declared_caches={name: native_cache_dir(owners[name]) for name in paths},
    outside_package=all(not path.resolve().is_relative_to(package) for path in paths.values()),
    under_declared_cache=all(path.resolve().is_relative_to(Path(native_cache_dir(owners[name])).resolve()) for name, path in paths.items()),
    source_unchanged=snapshot == json.loads(Path("installed_snapshot.json").read_text()))))
\'\'\'
    r = run([str(py), "-I", "-c", locations], env, work)'''
assert old in s;s=s.replace(old,new)
old='''if not isinstance(nb, dict) or not all(nb.get(k) for k in ("cex_lib_exists", "stream_lib_exists", "heat_record_exists")) or not all("site-packages" in nb.get(k, "") for k in ("cex_lib", "stream_lib", "heat_record")): failures.append("native_build_locations: kernels not built inside the installation")'''
new='''if not isinstance(nb, dict) or not all(nb.get(k) is True for k in ("cex_lib_exists", "stream_lib_exists", "heat_record_exists", "outside_package", "under_declared_cache", "source_unchanged")): failures.append("native_build_locations: native artifacts must exist under declared external caches without changing installed package files")'''
assert old in s;s=s.replace(old,new);p.write_text(s)
p=r/'tests/test_qualification_tools.py';s=p.read_text().replace('heat_record_exists=True)', 'heat_record_exists=True, outside_package=True, under_declared_cache=True, source_unchanged=True)')
s=s.replace('        "CBI not certified":','        "native build modifies installation": lambda r: r["steps"]["native_build_locations"]["result"].update(source_unchanged=False),\n        "native build escapes declared cache": lambda r: r["steps"]["native_build_locations"]["result"].update(under_declared_cache=False),\n        "CBI not certified":')
p.write_text(s)
