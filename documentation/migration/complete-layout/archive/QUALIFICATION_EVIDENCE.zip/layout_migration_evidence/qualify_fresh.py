from pathlib import Path
import hashlib,json
r=Path('/workspace/scratch/226d1e4428b0/pgm-layout-migration')
p=r/'tests/qualification/qualify.sh';s=p.read_text();s=s.replace('set -u\nPY="$1"; BPY="$2"; SCR="${3:-$(mktemp -d /tmp/pgm-qualify-XXXXXX)}"','''set -u
PY="$1"; BPY="$2"
if [ "$#" -ge 3 ]; then
    SCR="$3"
    if [ -e "$SCR" ]; then echo "Scratch directory must be new: $SCR" >&2; exit 2; fi
    mkdir -p "$SCR" || exit 2
else
    SCR="$(mktemp -d /tmp/pgm-qualify-XXXXXX)"
fi
if [ -z "${PARITY_REFERENCE:-}" ] && [ -z "${PGM_BASELINE_ROOT:-}" ]; then
    echo "Set PARITY_REFERENCE to an explicit same-host reference, or PGM_BASELINE_ROOT to its pinned checkout" >&2; exit 2
fi''')
s=s.replace('run 03_parity_compare "$PY" tests/parity/compare.py "$SCR/parity_final.json" --report "$Q/parity_report.json"','''if [ -n "${PARITY_REFERENCE:-}" ]; then
    REF="$PARITY_REFERENCE"
else
    REF="$SCR/parity_baseline.json"
    ( cd "$PGM_BASELINE_ROOT" && run 02b_baseline_generate env PYTHONPATH="$PGM_BASELINE_ROOT/src:$PGM_BASELINE_ROOT/code" "$PY" tests/parity/generate_reference.py "$REF" )
fi
run 03_parity_compare "$PY" tests/parity/compare.py "$SCR/parity_final.json" --reference "$REF" --report "$Q/parity_report.json"''')
old='''rm -rf "$SCR/dist" "$REPO/build" "$REPO/pgm_certified.egg-info"
run 08_wheel_build "$BPY" -m build --wheel --no-isolation --outdir "$SCR/dist" .
rm -rf "$REPO/build" "$REPO/pgm_certified.egg-info"'''
new='''"$PY" - "$REPO" "$SCR/wheel_source" <<'COPYEOF'
from pathlib import Path
import shutil, sys
source, target = map(Path, sys.argv[1:]); target.mkdir()
shutil.copy2(source / "pyproject.toml", target / "pyproject.toml")
shutil.copytree(source / "src", target / "src", ignore=shutil.ignore_patterns("__pycache__", "*.pyc", "*.egg-info", "native_cache"))
COPYEOF
run 08_wheel_build "$BPY" -m build --wheel --no-isolation --outdir "$SCR/dist" "$SCR/wheel_source"'''
assert old in s;s=s.replace(old,new);p.write_text(s)
ledger=Path('/workspace/scratch/226d1e4428b0/layout_migration_evidence/benchmark_moves.json');rows=json.loads(ledger.read_text())
for old,new in [('benchmarks/external/provenance/BUILD_LIBDAI.sh','benchmarks/external/comparators/libdai/build.sh'),('benchmarks/external/provenance/qualify_libdai.py','benchmarks/external/comparators/libdai/qualify.py')]:
 src,dst=r/old,r/new
 # old hash is the pre-migration git blob, not the already-updated working bytes.
 import subprocess
 olddata=subprocess.check_output(['git','show','HEAD:'+old],cwd=r)
 src.rename(dst);rows.append(dict(old=old,new=new,old_sha256=hashlib.sha256(olddata).hexdigest()))
p=r/'benchmarks/external/comparators/libdai/qualify.py';s=p.read_text();start=s.index('ROOT=Path(');end=s.index('CASES=[',start)
s=s[:start]+'''if len(sys.argv) != 2:
 raise SystemExit("usage: PGM_LIBDAI=/path/to/libdai_mar python qualify.py NEW_OUTPUT_DIRECTORY")
ROOT=Path(sys.argv[1]).expanduser().resolve()
if ROOT.exists(): raise SystemExit("Refusing existing qualification output: " + str(ROOT))
ROOT.mkdir(parents=True)
BIN=Path(os.environ.get('PGM_LIBDAI', Path(__file__).resolve().parent/'libdai_mar')).resolve()
RECORD=ROOT/'LIBDAI_QUALIFICATION.json'
OUT=ROOT/'qualification'
OUT.mkdir()
'''+s[end:];p.write_text(s)
p=r/'benchmarks/external/comparators/libdai/build.sh';p.write_text('''#!/usr/bin/env bash
# Host build from pinned release archives, entirely in a new external directory.
# Usage: build.sh ARCHIVE_DIRECTORY NEW_OUTPUT_DIRECTORY [PYTHON]
set -euo pipefail
SOURCES="$(cd "${1:?release archive directory}" && pwd)"
OUTPUT="${2:?new output directory}"
PY="${3:-python3}"
SCRIPT="$(cd "$(dirname "$0")" && pwd)"
if [ -e "$OUTPUT" ]; then echo "Refusing existing build directory: $OUTPUT" >&2; exit 2; fi
mkdir -p "$OUTPUT"
cd "$OUTPUT"
OUTPUT="$PWD"
tar -xzf "$SOURCES/libDAI-0.3.2.tar.gz"
tar -xjf "$SOURCES/boost_1_83_0.tar.bz2" boost_1_83_0/boost
cp libDAI-0.3.2/Makefile.LINUX libDAI-0.3.2/Makefile.conf
make -C libDAI-0.3.2 -B -j2 lib DEBUG= CCINC='-Iinclude -I../boost_1_83_0' CCFLAGS='-O3 -std=c++11 -Wno-deprecated -Wall -W -Wextra -fpic' >libdai-build.log 2>&1
"${CXX:-g++}" -O3 -std=c++11 -IlibDAI-0.3.2/include -Iboost_1_83_0 "$SCRIPT/libdai_mar.cpp" -LlibDAI-0.3.2/lib -ldai -lgmpxx -lgmp -o libdai_mar >libdai-driver-build.log 2>&1
PGM_LIBDAI="$OUTPUT/libdai_mar" "$PY" "$SCRIPT/qualify.py" "$OUTPUT/qualification"
''')
for row in rows:
 row['new_sha256']=hashlib.sha256((r/row['new']).read_bytes()).hexdigest();row['byte_identical']=row['old_sha256']==row['new_sha256']
ledger.write_text(json.dumps(rows,indent=2)+'\n')
