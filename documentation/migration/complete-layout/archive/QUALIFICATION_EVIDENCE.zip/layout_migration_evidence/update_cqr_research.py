from pathlib import Path
import ast,re
root=Path('/workspace/scratch/226d1e4428b0/pgm-layout-migration'); folder=root/'research/campaigns/cqr'
for p in folder.glob('*.py'):
 if p.name.startswith('_'):continue
 text=p.read_text()
 text=re.sub(r'^(?:HERE|CODE|NEWARM) = .*\n','',text,flags=re.M)
 text=re.sub(r'^pass  # imports are package-qualified.*\n','',text,flags=re.M)
 # Canonical imports take priority; no bare CQR or per-directory module cache.
 text=text.replace('from research.campaigns.cqr import registry as PR','from ._legacy import load_pac\nPR = load_pac(\'registry\')')
 tree=ast.parse(text);lines=text.splitlines(keepends=True);offsets=[0]
 for line in lines:offsets.append(offsets[-1]+len(line))
 edits=[]
 for node in tree.body:
  if isinstance(node,ast.FunctionDef) and node.name in ('load_module','_load'):
   edits.append((offsets[node.lineno-1],offsets[node.end_lineno],''))
 for start,end,new in reversed(edits):text=text[:start]+new+text[end:]
 text=text.replace("PR = _load('pac_registry', os.path.join(PAC, 'registry.py'))", "from ._legacy import load_pac\nPR = load_pac('registry')")
 text=re.sub(r'^_m = sys.modules.get\(\'solve\'\).*\n','',text,flags=re.M)
 text=re.sub(r'^_solve = .*\n','from pgm.algorithms.cqr import solve as _solve\n',text,flags=re.M)
 replacements={
  "R = load_module('cqr_registry', os.path.join(HERE, 'registry.py'))":"from . import registry as R",
  "PC = load_module('pac_campaign', os.path.join(PAC, 'campaign.py'))":"from ._legacy import load_pac\nPC = load_pac('campaign')",
  "PG = load_module('pac_gate', os.path.join(PAC, 'gate.py'))":"from ._legacy import load_pac\nPG = load_pac('gate')",
  "KI = load_module('cqr_kernel_identity', os.path.join(HERE, 'kernel_identity.py'))":"from . import kernel_identity as KI",
  "RP = load_module('cqr_report', os.path.join(HERE, 'report.py'))":"from . import report as RP",
  "CG = load_module('cqr_gate', os.path.join(HERE, 'gate.py'))":"from . import gate as CG",
 }
 for old,new in replacements.items():text=text.replace(old,new)
 text=re.sub(r'^_spec = importlib.util.spec_from_file_location\(\'cqr_registry\'.*\n','from . import registry as REG\n',text,flags=re.M)
 # Preserve CQR-relative data paths; subprocesses run modules from repository root.
 text=re.sub(r'\[PY, os.path.join\(HERE, \'([a-zA-Z0-9_]+)\.py\'\)',r"[PY, '-m', 'research.campaigns.cqr.\1'",text)
 text=text.replace('cwd=CODE','cwd=ROOT')
 text=text.replace("os.path.join(CODE, 'runs',", "os.path.join(str(runs_root()),")
 text=text.replace("os.path.join(CODE, 'runs/mdi_2026-10-28/CQR_2026-11-15')", "os.path.join(str(runs_root()), 'mdi_2026-10-28/CQR_2026-11-15')")
 text=text.replace("os.path.join(HERE, 'compiler.py')", "source_path('pgm.algorithms.cqr.compiler')")
 text=text.replace("task_py=os.path.join(HERE, 'task.py')", "task_py=source_path('pgm.algorithms.cqr.task')")
 # Import shared research path/bootstrap before any canonical package imports.
 tree=ast.parse(text);body=tree.body; pos=0
 if body and isinstance(body[0],ast.Expr) and isinstance(body[0].value,ast.Constant) and isinstance(body[0].value.value,str):pos=body[0].end_lineno
 for node in body:
  if isinstance(node,ast.ImportFrom) and node.module=='__future__':pos=node.end_lineno
 lines=text.splitlines(keepends=True)
 lines.insert(pos,'from ._paths import HERE, ROOT, CODE, CEX, PAC, NEWARM, RUNTIME, PY, runs_root, source_path, subprocess_env\n')
 text=''.join(lines)
 p.write_text(text)
