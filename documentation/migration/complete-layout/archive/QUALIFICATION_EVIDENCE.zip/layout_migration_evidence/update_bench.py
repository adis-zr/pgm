from pathlib import Path
r=Path('/workspace/scratch/226d1e4428b0/pgm-layout-migration')
p=r/'benchmarks/external/comparators/pgmax_mar.py';s=p.read_text();s='\n'.join(x for x in s.splitlines() if not x.startswith('sys.path.insert('))+'\n';p.write_text(s)
p=r/'tests/specialists/test_cbi_conformance.py';s=p.read_text().replace('os.path.join(HERE, "runs/mdi_', 'os.path.join(os.environ.get("PGM_RECORDS_ROOT", HERE), "code/runs/mdi_');p.write_text(s)
p=r/'tests/qualification/run_inherited_controls.py';s=p.read_text().replace('ap.add_argument("--records-root", default=None)', 'ap.add_argument("--records-root", default=os.environ.get("PGM_RECORDS_ROOT"))');p.write_text(s)
p=r/'tests/qualification/qualify.sh';s=p.read_text();start=s.index('set -u');s='''#!/bin/sh
# Qualify the current layout into a fresh scratch directory. Archived qualification
# receipts are never overwritten. Usage: qualify.sh PYTHON BUILD_PYTHON [SCRATCH]
'''+s[start:]
s=s.replace('$(dirname "$0")/../../../..','$(dirname "$0")/../..').replace('Q="$REPO/documentation/consolidation/step1/qualification/06_final"; T="$REPO/documentation/consolidation/step1/tools"','Q="$SCR/qualification"; T="$REPO/tests/qualification"')
s=s.replace('mkdir -p "$Q" "$SCR"; cd "$REPO" || exit 2','if [ -e "$Q" ]; then echo "Refusing existing qualification directory: $Q" >&2; exit 2; fi\nmkdir -p "$Q" "$SCR"; cd "$REPO" || exit 2')
s=s.replace('export PYTHONPATH="$REPO/src:$REPO/code"','export PYTHONPATH="$REPO/src:$REPO"')
s=s.replace('( cd code/cex/hp && run 04_check_dgp10 "$PY" check_dgp10.py "$Q/check_dgp10.json" )','run 04_check_dgp10 "$PY" -m research.campaigns.hp.check_dgp10 "$Q/check_dgp10.json"')
s=s.replace('( cd code/cex/hp && run 05_dgp10_oracle "$PY" dgp10_oracle.py "$Q/dgp10_oracle.json" )','run 05_dgp10_oracle "$PY" -m research.campaigns.hp.dgp10_oracle "$Q/dgp10_oracle.json"')
s=s.replace('pytest code/tests','pytest tests/specialists tests/benchmark_legacy')
s=s.replace('run 10_closure_manifest "$PY" "$T/manifest.py"\nrun 11_classification "$PY" "$T/classify_tree.py"\n','')
s=s.replace(', "10_closure_manifest", "11_classification"','')
p.write_text(s)
