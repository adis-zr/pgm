from pathlib import Path
import ast
r=Path('/workspace/scratch/226d1e4428b0/pgm-layout-migration')
p=r/'tests/specialists/test_h4a_review2.py';s=p.read_text().replace('from pgm.algorithms.h4.kernels import build_dir\nBUILD = build_dir()', 'from pgm.algorithms.h4.kernels import kernel_path').replace('str(BUILD / exe)', 'str(kernel_path(exe))');p.write_text(s)
p=r/'tests/qualification/clean_wheel_relocation_test.py';s=p.read_text()
s=s.replace('if not isinstance((sp.get("h4a") or {}).get("available"), bool): failures.append("specialists: h4a report")','''h4 = sp.get("h4a") or {}
        if h4.get("available") is not True or h4.get("witness") != {"all_ok": True, "roles": 4, "verdicts": {"C": "VERIFIED", "PI": "VERIFIED", "PP": "VERIFIED"}} or h4.get("source_unchanged") is not True: failures.append("specialists: H4 installed native witnesses and independent checks")''')
s=s.replace('any(not item.get("module", "").startswith("pgm.") or item.get("status") != "specialist" for item in registry.values())','any(not item.get("module", "").startswith("pgm.") or item.get("status") != {"cbi": "specialist", "sf": "specialist", "cqr": "specialist", "h4": "reference"}.get(name) for name, item in registry.items())')
ref=(r/'tests/test_h4_migration.py').read_text();tree=ast.parse(ref);func=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='run_tiny_witness');snippet=ast.get_source_segment(ref,func)
old='out["h4a"] = h4a.available()'
new='''from pathlib import Path
import hashlib, os, subprocess
from fractions import Fraction as F
from pgm.algorithms.h4 import kernels
os.environ["PGM_NATIVE_CACHE"] = str(Path("h4_native_cache").resolve())
source = Path(kernels.__file__).parent
before = {str(p.relative_to(source)): hashlib.sha256(p.read_bytes()).hexdigest() for p in source.rglob("*") if p.is_file() and "__pycache__" not in p.parts}
kernels.build_all()
'''+snippet+'''
witness = run_tiny_witness("h4_witness")
after = {str(p.relative_to(source)): hashlib.sha256(p.read_bytes()).hexdigest() for p in source.rglob("*") if p.is_file() and "__pycache__" not in p.parts}
out["h4a"] = dict(h4a.available(), witness=witness, source_unchanged=before == after)
'''
assert old in s;s=s.replace(old,new);p.write_text(s)
p=r/'tests/test_qualification_tools.py';s=p.read_text().replace('h4a=dict(available=False)', 'h4a=dict(available=True, witness=dict(all_ok=True, roles=4, verdicts={name: "VERIFIED" for name in ("C", "PI", "PP")}), source_unchanged=True)').replace('status="specialist") for name in ("cbi", "sf", "cqr", "h4")', 'status="reference" if name == "h4" else "specialist") for name in ("cbi", "sf", "cqr", "h4")')
s=s.replace('        "method omitted":', '        "h4 checker not run": lambda r: r["steps"]["specialists"]["result"]["h4a"]["witness"]["verdicts"].update(PP="FAILED"),\n        "h4 mutates installed source": lambda r: r["steps"]["specialists"]["result"]["h4a"].update(source_unchanged=False),\n        "method omitted":')
p.write_text(s)
