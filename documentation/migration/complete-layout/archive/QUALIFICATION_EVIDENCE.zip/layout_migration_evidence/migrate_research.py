from pathlib import Path
import ast, hashlib, json, re, shutil
ROOT=Path('/workspace/scratch/226d1e4428b0/pgm-layout-migration')
records=[]; canonical={}; aliases={}; active=[]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for family in ['hp','newarm','blockres']:
 for p in (ROOT/'code/cex'/family).glob('*.py'):
  s=p.read_text()
  if s.startswith('"""COMPATIBILITY SHIM'):
   module=re.search(r'canonical module is `([^`]+)`',s).group(1)
   canonical[p.stem]=module
for family in ['b0_frozen_v14','baseline','newarm_dev','pac']:
 source=ROOT/'code/cex'/family; target=ROOT/'research/archive'/family
 for p in source.rglob('*'):
  if p.is_file(): records.append(dict(old=str(p.relative_to(ROOT)),new=str((target/p.relative_to(source)).relative_to(ROOT)),sha256_before=sha(p),action='archive_byte_identical'))
 shutil.move(source,target)
for oldfamily,newfamily in [('hp','hp'),('newarm','structural'),('blockres','blockres')]:
 source=ROOT/'code/cex'/oldfamily; target=ROOT/'research/campaigns'/newfamily; target.mkdir(parents=True,exist_ok=True)
 for p in list(source.rglob('*')):
  if not p.is_file(): continue
  old=str(p.relative_to(ROOT)); digest=sha(p)
  if p.suffix=='.py' and p.stem in canonical and p.read_text().startswith('"""COMPATIBILITY SHIM'):
   records.append(dict(old=old,new='src/'+canonical[p.stem].replace('.','/')+'.py',canonical_module=canonical[p.stem],sha256_before=digest,action='remove_duplicate_alias'))
   p.unlink(); continue
  q=target/p.relative_to(source); q.parent.mkdir(parents=True,exist_ok=True); shutil.move(p,q)
  records.append(dict(old=old,new=str(q.relative_to(ROOT)),sha256_before=digest,action='relocate_campaign'))
  if q.suffix=='.py':
   active.append(q); aliases[q.stem]='research.campaigns.'+newfamily+'.'+q.stem
 for d in sorted(source.rglob('*'),reverse=True):
  if d.is_dir(): d.rmdir()
 source.rmdir()
 (target/'__init__.py').write_text('"""Research campaign controls and experiment tooling."""\n')
for old in ['code/cex/locked_plan.py','code/cex/gate_controls.py']:
 p=ROOT/old; q=ROOT/'research/archive/cex_tools'/p.name; q.parent.mkdir(parents=True,exist_ok=True)
 records.append(dict(old=old,new=str(q.relative_to(ROOT)),sha256_before=sha(p),action='archive_byte_identical')); shutil.move(p,q)
for p in (ROOT/'code/gbidi').glob('*'):
 if p.is_file():
  records.append(dict(old=str(p.relative_to(ROOT)),new='src/pgm/runtime/supervise.py' if p.name=='supervise.py' else None,sha256_before=sha(p),action='remove_duplicate_alias' if p.name=='supervise.py' else 'remove_empty_namespace'))
  assert p.name=='supervise.py' or not p.read_text().strip()
  p.unlink()
(ROOT/'code/gbidi').rmdir()
# Registry imports in hp refer to the archived PAC campaign, not pgm's public registry.
local_maps={p:dict(canonical,**aliases) for p in active}
HEADER='''\n# Source-checkout entry point; production imports never traverse research.\nif __package__ in (None, ""):\n    import sys as _research_sys\n    from pathlib import Path as _ResearchPath\n    _research_sys.path.insert(0, str(_ResearchPath(__file__).resolve().parents[3]))\nfrom research.bootstrap import activate as _activate_research\n_activate_research()\nfrom research.paths import repo_root as _repo_root, runs_root as _runs_root, records_root as _records_root, source_path as _source_path\n'''
for p in active:
 s=p.read_text(); tree=ast.parse(s); lines=s.splitlines(keepends=True); offsets=[]; z=0
 for line in lines: offsets.append(z); z+=len(line)
 def start(n): return offsets[n.lineno-1]+n.col_offset
 def end(n): return offsets[n.end_lineno-1]+n.end_col_offset
 edits=[]; mapping=local_maps[p]
 for n in ast.walk(tree):
  if isinstance(n,ast.Import):
   changed=False; parts=[]
   for a in n.names:
    name=mapping.get(a.name,a.name); changed|=name!=a.name
    parts.append(name+(' as '+(a.asname or a.name) if name!=a.name else (' as '+a.asname if a.asname else '')))
   if changed: edits.append((start(n),end(n),'import '+', '.join(parts)))
  elif isinstance(n,ast.ImportFrom) and n.level==0 and n.module in mapping:
   edits.append((start(n),end(n),'from '+mapping[n.module]+' import '+', '.join(a.name+(' as '+a.asname if a.asname else '') for a in n.names)))
  elif isinstance(n,ast.Expr) and isinstance(n.value,ast.Call):
   fun=ast.unparse(n.value.func)
   if fun in ('sys.path.insert','sys.path.append','sys.path.extend'):
    edits.append((start(n),end(n),'None  # research bootstrap owns imports'))
  elif isinstance(n,ast.Assign) and any(ast.unparse(t).startswith('sys.path[') for t in n.targets):
   edits.append((start(n),end(n),'None  # research bootstrap owns imports'))
  elif isinstance(n,ast.Call) and ast.unparse(n.func) in ('os.path.join','Path'):
   # A former adjacent shim now resolves to the canonical source file for subprocess use.
   if ast.unparse(n.func)=='os.path.join' and len(n.args)==2 and isinstance(n.args[0],ast.Name) and n.args[0].id in ('HERE','BASE') and isinstance(n.args[1],ast.Constant) and isinstance(n.args[1].value,str):
    stem=n.args[1].value.removesuffix('.py')
    if n.args[1].value.endswith('.py') and stem in canonical:
     edits.append((start(n),end(n),'_source_path('+repr(canonical[stem])+')'))
 for a,b,v in sorted(edits,reverse=True): s=s[:a]+v+s[b:]
 # Header must follow docstring / future imports.
 t=ast.parse(s); at=0
 for n in t.body:
  if (isinstance(n,ast.Expr) and isinstance(n.value,ast.Constant) and isinstance(n.value.value,str)) or (isinstance(n,ast.ImportFrom) and n.module=='__future__'):
   at=sum(len(x) for x in s.splitlines(keepends=True)[:n.end_lineno])
  else: break
 s=s[:at]+HEADER+s[at:]
 # Current operational code paths; historical evidence JSON and archive snapshots untouched.
 s=s.replace("os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))", "str(_repo_root())")
 s=s.replace("os.path.dirname(os.path.dirname(os.path.dirname(HERE)))", "str(_repo_root())")
 s=s.replace("os.path.dirname(os.path.dirname(HERE))", "str(_repo_root())")
 for a,b in [('code/cex/hp','research/campaigns/hp'),('code/cex/blockres','research/campaigns/blockres'),('code/cex/newarm','research/campaigns/structural'),('code/cex/pac','research/archive/pac'),('code/gbidi/supervise.py','src/pgm/runtime/supervise.py')]: s=s.replace(a,b)
 p.write_text(s); ast.parse(s)
for r in records:
 if r.get('new') and (ROOT/r['new']).is_file(): r['sha256_after']=sha(ROOT/r['new'])
 if r['action']=='archive_byte_identical': assert r['sha256_after']==r['sha256_before'],r
out=Path('/workspace/scratch/226d1e4428b0/layout_migration_evidence/research_moves.json'); out.write_text(json.dumps({'records':records,'canonical_imports':canonical,'campaign_imports':aliases},indent=2)+'\n')
print('moved',len(records),'active Python',len(active),'canonical aliases',len(canonical))
