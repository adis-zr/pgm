from pathlib import Path
from collections import Counter
import json,hashlib,subprocess
root=Path('/workspace/scratch/226d1e4428b0/pgm-layout-migration');ev=Path('/workspace/scratch/226d1e4428b0/layout_migration_evidence')
base=json.loads((ev/'BASELINE_CODE_FILES.json').read_text()); commit=base['baseline_commit']; rows=[]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for name in ('benchmark_moves','cbi_sf_moves','cqr_moves','h4_moves','research_moves'):
 d=json.loads((ev/(name+'.json')).read_text());d=d.get('records',d.get('moves')) if isinstance(d,dict) else d
 for x in d:
  old=x['old'];new=x.get('new');before=x.get('old_sha256',x.get('sha256_before',x.get('before_sha256')))
  assert before
  actual_old=base['files'].get(old) or hashlib.sha256(subprocess.check_output(['git','show',commit+':'+old],cwd=root)).hexdigest()
  assert before==actual_old,(old,'oldhash')
  if new:assert(root/new).is_file(),new
  after=sha(root/new) if new else None
  action=x.get('action') or ('update_facade_import' if old==new else 'archive_byte_identical' if new and new.startswith('research/archive/') and before==after else 'relocate')
  if action=='archive_byte_identical':assert before==after,old
  meta={k:v for k,v in x.items() if k not in ('old','new','old_sha256','new_sha256','sha256_before','sha256_after','before_sha256','after_sha256','byte_identical','bytes_unchanged','action')}
  rows.append(dict(old=old,new=new,action=action,old_sha256=before,new_sha256=after,byte_identical=before==after if new else False,old_path_removed=old!=new,source_map=name+'.json',**meta))
for old,new in [('src/pgm/specialists/_bridge.py','research/archive/layout_tools/specialist_bridge.py'),('tests/test_compat_shims.py','research/archive/layout_tests/test_compat_shims.py'),('research/CLASSIFICATION.json','research/archive/layout_tools/CLASSIFICATION_STEP1.json')]:
 before=hashlib.sha256(subprocess.check_output(['git','show',commit+':'+old],cwd=root)).hexdigest();after=sha(root/new);assert before==after
 rows.append(dict(old=old,new=new,action='archive_byte_identical',old_sha256=before,new_sha256=after,byte_identical=True,old_path_removed=True,source_map='root_additional_moves',reason='Retained historical layout tool or evidence; not part of the installed production package.'))
counts=Counter(x['old'] for x in rows);assert all(n==1 for n in counts.values())
old_code={x['old'] for x in rows if x['old'].startswith('code/')};assert old_code==set(base['files']);assert len(old_code)==485
out={'schema':'PGM_COMPLETE_LAYOUT_MIGRATION_V1','baseline_commit':commit,'baseline_scope':'every tracked file under code/ at baseline_commit; additional displaced non-code tools and facade import updates listed separately by path','old_code_files':base['files'],'counts':{'baseline_code_files':485,'code_dispositions':485,'additional_dispositions':len(rows)-485,'total_dispositions':len(rows),'archived_byte_identical':sum(x['action']=='archive_byte_identical' for x in rows),'removed_empty_files':sum(x['new'] is None for x in rows),'canonical_alias_replacements':sum(x['action']=='remove_duplicate_alias' for x in rows),'byte_identical_preserved_copies':sum(len(x.get('preserved_copies',[])) for x in rows)},'hash_semantics':'SHA-256 of raw file bytes. old hashes independently checked against baseline git blobs. new hashes capture the final migration working tree; this is a migration snapshot, not a claim that subsequent implementation changes must remain byte-identical. Frozen archived source and evidence remain byte-identical.','entries':sorted(rows,key=lambda x:x['old'])}
dest=root/'documentation/migration/complete-layout/MIGRATION.json';dest.parent.mkdir(parents=True,exist_ok=True);dest.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out['counts']))
