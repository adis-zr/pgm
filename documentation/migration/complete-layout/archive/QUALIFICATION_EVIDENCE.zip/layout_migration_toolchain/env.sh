source /workspace/scratch/226d1e4428b0/performance_toolchain/env.sh
export CPATH=/workspace/scratch/226d1e4428b0/layout_migration_toolchain/mpfr/usr/include
export LIBRARY_PATH=/workspace/scratch/226d1e4428b0/layout_migration_toolchain/mpfr/usr/lib/x86_64-linux-gnu
export PGM_NATIVE_CACHE=/workspace/scratch/226d1e4428b0/layout_migration_toolchain/native_cache
